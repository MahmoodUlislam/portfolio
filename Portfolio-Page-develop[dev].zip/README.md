Hello everyone!
My name is Mahmood ul Islam.
This is my portfolio page's repo. If you want to dig in deeper in its codebase, feel welcome :) 
The purpose of this page is to inroduce my person, my coding style, and show off a little bit of my web development skills.

Current TO-DO's:
- cover with tests,
- implementation of translation,
- introduce context.
