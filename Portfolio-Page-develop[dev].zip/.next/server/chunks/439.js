exports.id = 439;
exports.ids = [439];
exports.modules = {

/***/ 7439:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ VContacts)
});

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "@googlemaps/react-wrapper"
var react_wrapper_ = __webpack_require__(4223);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "react-awesome-reveal"
var external_react_awesome_reveal_ = __webpack_require__(104);
// EXTERNAL MODULE: ./utils/index.ts + 8 modules
var utils = __webpack_require__(7090);
// EXTERNAL MODULE: ./utils/Navbar.jsx + 1 modules
var Navbar = __webpack_require__(3202);
// EXTERNAL MODULE: external "emailjs-com"
var external_emailjs_com_ = __webpack_require__(5230);
var external_emailjs_com_default = /*#__PURE__*/__webpack_require__.n(external_emailjs_com_);
// EXTERNAL MODULE: external "@mui/material/TextField"
var TextField_ = __webpack_require__(8258);
var TextField_default = /*#__PURE__*/__webpack_require__.n(TextField_);
// EXTERNAL MODULE: external "@mui/material/Button"
var Button_ = __webpack_require__(1874);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button_);
// EXTERNAL MODULE: external "react-quilljs"
var external_react_quilljs_ = __webpack_require__(6199);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./utils/quill.jsx




function Quill(...props) {
  const {
    quill,
    quillRef
  } = (0,external_react_quilljs_.useQuill)();
  external_react_default().useEffect(() => {
    if (quill) {
      quill.clipboard.dangerouslyPasteHTML('<h3>Enter your message...</h3>');
    }
  }, [quill]);
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    style: {
      width: '60%',
      height: '100%',
      marginTop: '2vh',
      backgroundColor: '#ff0072',
      color: '#ffffff'
    },
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      ref: quillRef
    })
  });
}
;// CONCATENATED MODULE: ./utils/VContactsForm.jsx







function VContactsForm(...pageProps) {
  function sendEmail(e) {
    e.preventDefault();
    external_emailjs_com_default().sendForm("service_kt1axgb", "template_g9bz5ie", e.target, "user_BGpWSgle5uZtYnn9HHBjV").then(result => {
      console.log("service_kt1axgb");
      alert(result.text);
    }, error => {
      alert(error.text);
    });
    e.target.reset();
  }

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx("form", {
      onSubmit: sendEmail,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        style: {
          display: 'flex',
          alignItems: 'center',
          flexDirection: 'column'
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx((TextField_default()), {
          color: "primary",
          sx: {
            borderRadius: '5px',
            width: '60%',
            backgroundColor: '#ff0072'
          },
          color: "secondary",
          id: "outlined-basic",
          label: "Enter your Name",
          variant: "filled",
          name: "from_name"
        }), /*#__PURE__*/jsx_runtime_.jsx((TextField_default()), {
          sx: {
            width: '60%',
            marginTop: '2vh',
            backgroundColor: '#ff0072',
            color: '#ffffff'
          },
          id: "outlined-basic",
          label: "Enter your email",
          variant: "filled",
          color: "secondary",
          name: "reply_to"
        }), /*#__PURE__*/jsx_runtime_.jsx((TextField_default()), {
          sx: {
            width: '60%',
            marginTop: '2vh',
            backgroundColor: '#ff0072',
            color: '#ffffff'
          },
          id: "outlined-basic",
          label: "Enter Subject",
          color: "secondary",
          variant: "filled",
          name: "subject"
        }), /*#__PURE__*/jsx_runtime_.jsx(Quill, {
          name: "message"
        }), /*#__PURE__*/jsx_runtime_.jsx((Button_default()), {
          style: {
            width: '30%',
            height: '7vh',
            marginTop: '4vh',
            backgroundColor: "#260316",
            color: '#ff0072',
            border: "3px solid #ff0072"
          },
          variant: "contained",
          type: "submit",
          children: "SUBMIT"
        })]
      })
    })
  });
}
// EXTERNAL MODULE: external "@react-google-maps/api"
var api_ = __webpack_require__(960);
;// CONCATENATED MODULE: ./utils/VGoogleMap.jsx




const containerStyle = {
  width: '80vw',
  height: '60vh'
};
const center = {
  lat: 23.870571178094686,
  lng: 90.39377666786204
};

function VGoogleMap() {
  const {
    isLoaded
  } = (0,api_.useJsApiLoader)({
    id: 'google-map-script',
    googleMapsApiKey: "AIzaSyAgz3Tlv8m9AYdx_or26x_UZmElZK-zOmM"
  });
  const [map, setMap] = external_react_default().useState(null);
  const onLoad = external_react_default().useCallback(function callback(map) {
    const bounds = new window.google.maps.LatLngBounds();
    bounds.extend(center);
    map.fitBounds(bounds);
    setMap(map);
  }, []);
  const onUnmount = external_react_default().useCallback(function callback(map) {
    setMap(null);
  }, []);
  return isLoaded ? /*#__PURE__*/jsx_runtime_.jsx(api_.GoogleMap, {
    mapContainerStyle: containerStyle,
    center: center,
    zoom: 16,
    onLoad: onLoad,
    onUnmount: onUnmount,
    children: /*#__PURE__*/jsx_runtime_.jsx(api_.Marker, {
      position: center,
      onRightClick: () => props.onMarkerRightClick(marker)
    }, 1)
  }) : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
}

/* harmony default export */ const utils_VGoogleMap = (/*#__PURE__*/external_react_default().memo(VGoogleMap));
// EXTERNAL MODULE: ./pages/contacts/contacts.module.scss
var contacts_module = __webpack_require__(3206);
var contacts_module_default = /*#__PURE__*/__webpack_require__.n(contacts_module);
// EXTERNAL MODULE: ./utils/typingtext.tsx
var typingtext = __webpack_require__(6330);
;// CONCATENATED MODULE: ./pages/contacts/contacts.jsx











 // const render = (status: Status): ReactElement => {
//   if (status === Status.LOADING) return ('Loading...');
//   if (status === Status.FAILURE) return ('Failed to load');
//   return null;
// };




function VContacts() {
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (contacts_module_default()).aboutContainer,
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
        children: [/*#__PURE__*/jsx_runtime_.jsx("title", {
          children: "Contacts"
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "description",
          content: "Mahmood ul Islam Portfolio contact Page"
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "author",
          content: "Mahmood ul Islam"
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "keywords",
          content: "Mahmood, Mahmood ul Islam, Portfolio, Frontend"
        }), /*#__PURE__*/jsx_runtime_.jsx("link", {
          rel: "shortcut icon",
          href: "/Mi-logo.svg",
          type: "image/x-icon"
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(Navbar/* default */.Z, {
        activeTab: "Contacts"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (contacts_module_default()).content,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (contacts_module_default()).summary,
          children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
            children: "Contacts"
          }), /*#__PURE__*/jsx_runtime_.jsx(external_react_awesome_reveal_.Fade, {
            children: /*#__PURE__*/jsx_runtime_.jsx("h2", {
              children: (0,typingtext/* useTypedText */.q)(`Email: mahmood.islam@gmail.com, Phone# +8801717077230                  
        Please use the form below to send us an email. We will get back to you as soon as possible...
        `, 30, 350)
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(external_react_awesome_reveal_.Fade, {
            children: /*#__PURE__*/jsx_runtime_.jsx(VContactsForm, {})
          }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              style: {
                textDecoration: 'none',
                color: 'white'
              },
              href: "https://github.com/MahmoodUlislam/",
              target: "_blank",
              rel: "noreferrer",
              children: "#GitHub: https://github.com/MahmoodUlislam"
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              style: {
                textDecoration: 'none',
                color: 'white'
              },
              href: "https://github.com/MahmoodUlislam/",
              target: "_blank",
              rel: "noreferrer",
              children: "#GitHub: https://github.com/MahmoodUlislam"
            })
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(external_react_awesome_reveal_.Fade, {
          children: /*#__PURE__*/jsx_runtime_.jsx("h2", {
            children: (0,typingtext/* useTypedText */.q)(`Mailing Address: House#37, Flat#B4, Sector#7, Road: (lake drive road), Uttara, Dhaka-1230, Bangladesh...`, 30, 350)
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(react_wrapper_.Wrapper, {
          apiKey: "AIzaSyAgz3Tlv8m9AYdx_or26x_UZmElZK-zOmM",
          children: /*#__PURE__*/jsx_runtime_.jsx(utils_VGoogleMap, {})
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(utils/* VFooter */.cI, {})]
    })
  });
}

/***/ }),

/***/ 3206:
/***/ ((module) => {

// Exports
module.exports = {
	"aboutContainer": "contacts_aboutContainer__q1DxK",
	"content": "contacts_content__38r-W",
	"summary": "contacts_summary__9KKam",
	"hobbies": "contacts_hobbies__250W0",
	"newsletters": "contacts_newsletters__WfBYX",
	"commissions": "contacts_commissions__1pWrk",
	"scrollGallery": "contacts_scrollGallery__1K3zx",
	"hint": "contacts_hint__3Do25",
	"pulse": "contacts_pulse__108fF",
	"photoGallery": "contacts_photoGallery__1GNJO"
};


/***/ })

};
;