exports.id = 643;
exports.ids = [643];
exports.modules = {

/***/ 5615:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Dd": () => (/* reexport */ chevronDown),
  "QC": () => (/* reexport */ cssLogo),
  "OA": () => (/* reexport */ cssLogoHover),
  "gA": () => (/* reexport */ github),
  "X3": () => (/* reexport */ githubHover),
  "Nv": () => (/* reexport */ git_logo),
  "lj": () => (/* reexport */ git_logo_hover),
  "Pv": () => (/* reexport */ gmail),
  "vR": () => (/* reexport */ gmailHover),
  "ge": () => (/* reexport */ htmlLogo),
  "Jv": () => (/* reexport */ htmlLogoHover),
  "wH": () => (/* reexport */ jestLogo),
  "AO": () => (/* reexport */ jestLogoHover),
  "f7": () => (/* reexport */ jsLogo),
  "po": () => (/* reexport */ jsLogoHover),
  "Ys": () => (/* reexport */ linkedin),
  "aj": () => (/* reexport */ linkedinHover),
  "CJ": () => (/* reexport */ nextjs_logo),
  "go": () => (/* reexport */ nextjs_logo_Hover),
  "Ky": () => (/* reexport */ npmLogo),
  "Wj": () => (/* reexport */ npmLogoHover),
  "rp": () => (/* reexport */ reactLogo),
  "w0": () => (/* reexport */ reactLogoHover),
  "bF": () => (/* reexport */ sassLogo),
  "bL": () => (/* reexport */ sassLogoHover),
  "rq": () => (/* reexport */ tsLogo),
  "Pz": () => (/* reexport */ tsLogoHover),
  "XL": () => (/* reexport */ vsLogo),
  "wF": () => (/* reexport */ vsLogoHover),
  "os": () => (/* reexport */ yarnLogo),
  "dP": () => (/* reexport */ yarnLogoHover)
});

// UNUSED EXPORTS: profilePicture, profilePicture1

;// CONCATENATED MODULE: ./assets/logos/htmlLogo.svg
/* harmony default export */ const htmlLogo = ({"src":"/_next/static/image/assets/logos/htmlLogo.aff8a9cb398fc75e4f21dab1ba1e097e.svg","height":512,"width":512});
;// CONCATENATED MODULE: ./assets/logos/htmlLogoHover.svg
/* harmony default export */ const htmlLogoHover = ({"src":"/_next/static/image/assets/logos/htmlLogoHover.41a6496176efbd541cff35655ef10bf0.svg","height":512,"width":512});
;// CONCATENATED MODULE: ./assets/logos/cssLogo.svg
/* harmony default export */ const cssLogo = ({"src":"/_next/static/image/assets/logos/cssLogo.5da907d7f5cda48f093117458389fba7.svg","height":546,"width":387});
;// CONCATENATED MODULE: ./assets/logos/cssLogoHover.svg
/* harmony default export */ const cssLogoHover = ({"src":"/_next/static/image/assets/logos/cssLogoHover.644bfd5b8484f82b14e68f72e0179e08.svg","height":546,"width":387});
;// CONCATENATED MODULE: ./assets/logos/sassLogo.png
/* harmony default export */ const sassLogo = ({"src":"/_next/static/image/assets/logos/sassLogo.e8351b219b0da5b4c1010075e33fd2dc.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAoUlEQVR4nB2OMQ4BURRF76OSqDQiUVJS2IFYgehtwyYUKolO1OzGV6gFO1BMxptz5/+c/+/7c/LmRbmXrqQalJGcUrDlyGXBH4aRseGpR36Rr+Q6sSzMKbZwlvSAHdKeu0IMCweKI3xhDW/4IBWEtDDiYQV9mIDnmcIFioUxwb+YQQVPcJcbDQYWlhQLOMEP3KFdCO2QzEpgt8tXqsP5t9AAoH9HPL49GfIAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./assets/logos/sassLogoHover.png
/* harmony default export */ const sassLogoHover = ({"src":"/_next/static/image/assets/logos/sassLogoHover.233f970c6280e87e6a7eb5e7da27efa9.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAoUlEQVR4nC2PMQ4BURRF76OSqDQiUVJS2IFYgeiFVdiEQiXRiZrljEItxg4Uk/Gci5c58+/7c/Lm/yhX66akGpSR4vlXAD0CObt8XbDTQrpHxplc27UwZl3CUdIVNkhb1goxLOxo9vCEOTygRCoQ0kKPjRm0YQA+zxBOUFjoE/yLEVRwA0+5MKBjYUozgQO8wBN+xZUscBkyfMsh1eD9ZoI+18Y9jHiSW40AAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./assets/logos/jsLogo.svg
/* harmony default export */ const jsLogo = ({"src":"/_next/static/image/assets/logos/jsLogo.fd46ca41839433d73577989d86eb2fe2.svg","height":256,"width":256});
;// CONCATENATED MODULE: ./assets/logos/jsLogoHover.svg
/* harmony default export */ const jsLogoHover = ({"src":"/_next/static/image/assets/logos/jsLogoHover.1a3bd88c0786fb44a60e8b17228dc7f7.svg","height":256,"width":256});
;// CONCATENATED MODULE: ./assets/logos/reactLogo.svg
/* harmony default export */ const reactLogo = ({"src":"/_next/static/image/assets/logos/reactLogo.e28b4924d299f6a9ee4f7efc7a66a4fa.svg","height":230,"width":256});
;// CONCATENATED MODULE: ./assets/logos/reactLogoHover.svg
/* harmony default export */ const reactLogoHover = ({"src":"/_next/static/image/assets/logos/reactLogoHover.3517728e04206faf96ea68bb8e691620.svg","height":230,"width":256});
;// CONCATENATED MODULE: ./assets/logos/tsLogo.svg
/* harmony default export */ const tsLogo = ({"src":"/_next/static/image/assets/logos/tsLogo.a6305a733dd55243980aec55f96f70c5.svg","height":2500,"width":2500});
;// CONCATENATED MODULE: ./assets/logos/tsLogoHover.svg
/* harmony default export */ const tsLogoHover = ({"src":"/_next/static/image/assets/logos/tsLogoHover.f2e9d293b81d3e96a027e858162714c5.svg","height":2500,"width":2500});
;// CONCATENATED MODULE: ./assets/logos/gmail.svg
/* harmony default export */ const gmail = ({"src":"/_next/static/image/assets/logos/gmail.50437ec4a197f663fe43d93f9db45b6c.svg","height":510,"width":510});
;// CONCATENATED MODULE: ./assets/logos/gmailHover.svg
/* harmony default export */ const gmailHover = ({"src":"/_next/static/image/assets/logos/gmailHover.2a44bc8fbcd4039fdece40286a96580d.svg","height":510,"width":510});
;// CONCATENATED MODULE: ./assets/logos/npmLogo.png
/* harmony default export */ const npmLogo = ({"src":"/_next/static/image/assets/logos/npmLogo.f7509b5e9b295a6a82466325c8c95adc.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAXUlEQVR42m2NsQ1AYBgFv/zmEZRKGq0RFLTUgqjoVGzADCa5t4+IqHgv196ZPBwvTp59pp5KAxUdNQWt0SjXqJSJRKU208rOQsbBzMlpigipaYkJ8PF/pO5O3tHnF1WjNWBK6BhBAAAAAElFTkSuQmCC"});
;// CONCATENATED MODULE: ./assets/logos/npmLogoHover.png
/* harmony default export */ const npmLogoHover = ({"src":"/_next/static/image/assets/logos/npmLogoHover.a2c0786ec5a22062b6d215e77be470ab.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAoElEQVR4nEWPuw0CQQxEPRCSECGIKYCjARLqQNqrgAbogm4QARKVQMAvBIkQ8+YQd6Md2WPPer26ltKPiMwIhZRksoaGbGiVIdHH/q/ZsEHcycfwBkfwBZ9YJ7qUsubWKTNnxCNxSXNPc8q4yhO2TBhSfFDcka/Iz7CCPFHXc255swV6gOEQEW/0h9gY2Cn5wg8YGlg7t6FnA/D+LnI6fAEaPj4z3q7ESwAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./assets/logos/yarnLogo.svg
/* harmony default export */ const yarnLogo = ({"src":"/_next/static/image/assets/logos/yarnLogo.fb9154e1f8e9182f3aab56c6dea348ac.svg","height":652,"width":652});
;// CONCATENATED MODULE: ./assets/logos/yarnLogoHover.svg
/* harmony default export */ const yarnLogoHover = ({"src":"/_next/static/image/assets/logos/yarnLogoHover.9ed8a4a57b6cd974ad1e015a9657ae5a.svg","height":652,"width":652});
;// CONCATENATED MODULE: ./assets/logos/github.svg
/* harmony default export */ const github = ({"src":"/_next/static/image/assets/logos/github.242ddc416a01c9eec2e4771049d22863.svg","height":512,"width":512});
;// CONCATENATED MODULE: ./assets/logos/githubHover.svg
/* harmony default export */ const githubHover = ({"src":"/_next/static/image/assets/logos/githubHover.1353a57e7d6da8a25455baa671f6c7fb.svg","height":512,"width":512});
;// CONCATENATED MODULE: ./assets/logos/git-logo.svg
/* harmony default export */ const git_logo = ({"src":"/_next/static/image/assets/logos/git-logo.6cb0eaf71ccf525837267d7383643722.svg","height":108,"width":256});
;// CONCATENATED MODULE: ./assets/logos/git-logo - hover.svg
/* harmony default export */ const git_logo_hover = ({"src":"/_next/static/image/assets/logos/git-logo - hover.a0143c64c768a9a310b3c95ac4899b58.svg","height":108,"width":256});
;// CONCATENATED MODULE: ./assets/logos/jestLogo.png
/* harmony default export */ const jestLogo = ({"src":"/_next/static/image/assets/logos/jestLogo.8bb1378d414651c6208e1d3664120476.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAf0lEQVR42hXBsQoBAQDG8S8WMZIH8ACyKINJMXkB6TJc5FKyWOhCXcyklO6Gm267p/l/73Pd7yc3LI8p2RDw8V3UO+zoMfLUMyGGiCMFP6c05SUXYp948+fJXF6REfAl5uyESA7JfWONEJG38sN9BnQd+sqetrzg5QMJE7eQVAGY9EjUESoX/AAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./assets/logos/jestLogoHover.png
/* harmony default export */ const jestLogoHover = ({"src":"/_next/static/image/assets/logos/jestLogoHover.1571adec481f28f98f57a2035a1b8337.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAArElEQVR42mN4npDAxAAEQNr0eWLiumcJCfFAHAvkTwLiBgYYAApyAwXSgLQIEBsAsQ1QgxNMUg9K5wHxciCeDpScA6SZQYI+QJ1VzxITa4F0AZA/EYhnAdltQNqVAagyEsiZC8SxQPYUoGAtEJcC2S1AOhNkQjJQciGQrgfiaCQ3ZQLFU0GubwSqFgPSSkBBYaiGaiDOALK5QCrdgJx2IJ0NxC1AbAHUwAEzCQAcgm9oJJoMHAAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./assets/logos/linkedin.svg
/* harmony default export */ const linkedin = ({"src":"/_next/static/image/assets/logos/linkedin.ca54d191dcdef13e694cc197449830cd.svg","height":510,"width":510});
;// CONCATENATED MODULE: ./assets/logos/linkedinHover.svg
/* harmony default export */ const linkedinHover = ({"src":"/_next/static/image/assets/logos/linkedinHover.278875143436c2b6887cb5612e949f84.svg","height":510,"width":510});
;// CONCATENATED MODULE: ./assets/logos/vsLogo.svg
/* harmony default export */ const vsLogo = ({"src":"/_next/static/image/assets/logos/vsLogo.5f6c87ee85944898b6682f2a2a13df91.svg","height":100,"width":100});
;// CONCATENATED MODULE: ./assets/logos/vsLogoHover.svg
/* harmony default export */ const vsLogoHover = ({"src":"/_next/static/image/assets/logos/vsLogoHover.fa21cdb358e7f4a6a199949cb2d63937.svg","height":100,"width":100});
;// CONCATENATED MODULE: ./assets/logos/nextjs-logo.svg
/* harmony default export */ const nextjs_logo = ({"src":"/_next/static/image/assets/logos/nextjs-logo.e9d6856ed36aff9e41e1bb4b9460c2dd.svg","height":309,"width":512});
;// CONCATENATED MODULE: ./assets/logos/nextjs-logo -Hover.svg
/* harmony default export */ const nextjs_logo_Hover = ({"src":"/_next/static/image/assets/logos/nextjs-logo -Hover.cd33d279590fdbf01d6e602dcf80dd42.svg","height":309,"width":512});
;// CONCATENATED MODULE: ./assets/Group 1.png
/* harmony default export */ const Group_1 = ({"src":"/_next/static/image/assets/Group 1.be1f01dfc7f594c04317996c8a22e006.png","height":2048,"width":1536,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAYAAADaxo44AAAA00lEQVR4nAHIADf/AXNcRv72/QQANywiABEMCAC9ztkA5+zyAAFsXVD+7vPxAS0UDP8oGA8BvN3e/xsQCQEBcFlL/kJDMwD57+YAEfoPAChALgABBfkAAWtXU//9AgAA2NvuAB0UGwAYEBkA8PrVAAFXPij/EgoiAPP1CwCkw6sAdVlwADYt/gABAAAA/ls0QgEDDw7/9f0GASIcIv/b++sBAVZbYf4qA/AAFQ0SAMrhAgDc59oAEyIdAAGkn6b+7+7tAdnU0f+Un5wBEBsb/zYxOgFHU0voU7q/CgAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./assets/Group 2.png
/* harmony default export */ const Group_2 = ({"src":"/_next/static/image/assets/Group 2.7d549c76a5af6d02fd51419d0b5c7608.png","height":2048,"width":1536,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAYAAADaxo44AAAA00lEQVR4nAHIADf/AXNcRv72/QQANywiABEMCAC9ztkA5+zyAAFsXVD+7vPxAS0UDP8oGA8BvN3e/xsQCQEBcFlL/kJDMwD57+YAEfoPAChALgABBfkAAWxZVf/9AgAA19ntAB0UGgAYEBkA8PrVAAFQMgH/Fw89APf7FACixK4AdVlwADYt/gABTklS/hsOGQHt8O////j7ASAdI//b++sBAYySp/4aGxgA6NfSANTBywDY8OYAFCAaAAGSlKH+MjEwAcTAwf94e24BFB4d/zIuOAGMkk/oTx+9twAAAABJRU5ErkJggg=="});
;// CONCATENATED MODULE: ./assets/chevronDown.svg
/* harmony default export */ const chevronDown = ({"src":"/_next/static/image/assets/chevronDown.880a070a5e815d8e88bcfac4b559d159.svg","height":1440,"width":2560});
;// CONCATENATED MODULE: ./assets/index.ts


































/***/ }),

/***/ 4205:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ BackTop)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9693);
/* harmony import */ var _mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8082);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(380);
/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_useScrollTrigger__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6807);
/* harmony import */ var _mui_material_useScrollTrigger__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_useScrollTrigger__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1586);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Container__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1008);
/* harmony import */ var _mui_material_Container__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Container__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_Fab__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6847);
/* harmony import */ var _mui_material_Fab__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Fab__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_Zoom__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1377);
/* harmony import */ var _mui_material_Zoom__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Zoom__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }













function ScrollTop(props) {
  const {
    children,
    window
  } = props; // Note that you normally won't need to set the window ref as useScrollTrigger
  // will default to window.
  // This is only being set here because the demo is in an iframe.

  const trigger = _mui_material_useScrollTrigger__WEBPACK_IMPORTED_MODULE_4___default()({
    target: window ? window() : undefined,
    disableHysteresis: true,
    threshold: 100
  });

  const handleClick = event => {
    const anchor = (event.target.ownerDocument || document).querySelector('#back-to-top-anchor');

    if (anchor) {
      anchor.scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    }
  };

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx((_mui_material_Zoom__WEBPACK_IMPORTED_MODULE_8___default()), {
    in: trigger,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx((_mui_material_Box__WEBPACK_IMPORTED_MODULE_5___default()), {
      onClick: handleClick,
      role: "presentation",
      sx: {
        position: 'fixed',
        right: '5px',
        bottom: '5px'
      },
      children: children
    })
  });
}

function BackTop(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx((_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_3___default()), {}), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx((_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_1___default()), {
      id: "back-to-top-anchor"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(ScrollTop, _objectSpread(_objectSpread({}, props), {}, {
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx((_mui_material_Fab__WEBPACK_IMPORTED_MODULE_7___default()), {
        sx: {
          color: "#ff0072 !important",
          fontSize: "50px",
          paddingTop: "15px"
        },
        size: "small",
        "aria-label": "scroll back to top",
        children: "^"
      })
    }))]
  });
}

/***/ }),

/***/ 3202:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Navbar)
});

// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/AppBar/AppBar.js + 1 modules
var AppBar = __webpack_require__(8568);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/styles/makeStyles.js
var makeStyles = __webpack_require__(1120);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/styles/useTheme.js
var useTheme = __webpack_require__(8920);
// EXTERNAL MODULE: external "@mui/icons-material/AddShoppingCart"
var AddShoppingCart_ = __webpack_require__(8840);
// EXTERNAL MODULE: external "@mui/icons-material/MailOutline"
var MailOutline_ = __webpack_require__(7416);
var MailOutline_default = /*#__PURE__*/__webpack_require__.n(MailOutline_);
// EXTERNAL MODULE: external "@mui/icons-material/PersonOutline"
var PersonOutline_ = __webpack_require__(8782);
// EXTERNAL MODULE: external "@mui/icons-material/PhoneInTalk"
var PhoneInTalk_ = __webpack_require__(4512);
var PhoneInTalk_default = /*#__PURE__*/__webpack_require__.n(PhoneInTalk_);
// EXTERNAL MODULE: external "@mui/material/Container"
var Container_ = __webpack_require__(1008);
// EXTERNAL MODULE: external "@mui/material/Menu"
var Menu_ = __webpack_require__(2763);
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu_);
// EXTERNAL MODULE: external "@mui/material/MenuItem"
var MenuItem_ = __webpack_require__(5318);
var MenuItem_default = /*#__PURE__*/__webpack_require__.n(MenuItem_);
// EXTERNAL MODULE: external "@mui/material/Toolbar"
var Toolbar_ = __webpack_require__(9693);
// EXTERNAL MODULE: external "@mui/material/useMediaQuery"
var useMediaQuery_ = __webpack_require__(9688);
var useMediaQuery_default = /*#__PURE__*/__webpack_require__.n(useMediaQuery_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./utils/menubar.module.scss
var menubar_module = __webpack_require__(5237);
var menubar_module_default = /*#__PURE__*/__webpack_require__.n(menubar_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./utils/BackTop.jsx
var BackTop = __webpack_require__(4205);
// EXTERNAL MODULE: external "@material-ui/core"
var core_ = __webpack_require__(1731);
// EXTERNAL MODULE: ./assets/index.ts + 33 modules
var assets = __webpack_require__(5615);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/Button/Button.js + 13 modules
var Button = __webpack_require__(6207);
// EXTERNAL MODULE: ./node_modules/@material-ui/core/esm/Typography/Typography.js
var Typography = __webpack_require__(2318);
// EXTERNAL MODULE: external "@material-ui/icons/Menu"
var icons_Menu_ = __webpack_require__(1358);
var icons_Menu_default = /*#__PURE__*/__webpack_require__.n(icons_Menu_);
// EXTERNAL MODULE: external "@mui/icons-material/LinkedIn"
var LinkedIn_ = __webpack_require__(3573);
// EXTERNAL MODULE: external "@mui/icons-material/Search"
var Search_ = __webpack_require__(1893);
var Search_default = /*#__PURE__*/__webpack_require__.n(Search_);
// EXTERNAL MODULE: external "@mui/icons-material/GitHub"
var GitHub_ = __webpack_require__(4783);
// EXTERNAL MODULE: external "@mui/material/Divider"
var Divider_ = __webpack_require__(818);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider_);
// EXTERNAL MODULE: external "@mui/material/InputBase"
var InputBase_ = __webpack_require__(3973);
var InputBase_default = /*#__PURE__*/__webpack_require__.n(InputBase_);
// EXTERNAL MODULE: external "@mui/material/styles"
var styles_ = __webpack_require__(8035);
// EXTERNAL MODULE: ./utils/icon.tsx
var icon = __webpack_require__(1628);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./utils/DrawerComponent.jsx




















const Search = (0,styles_.styled)('div')(({
  theme
}) => ({
  position: 'relative',
  borderRadius: theme.shape.borderRadius,
  backgroundColor: (0,styles_.alpha)(theme.palette.common.white, 0.15),
  '&:hover': {
    backgroundColor: (0,styles_.alpha)(theme.palette.common.white, 0.25)
  },
  marginLeft: 0,
  width: '100%',
  [theme.breakpoints.up('sm')]: {
    marginLeft: theme.spacing(1),
    width: 'auto'
  }
}));
const SearchIconWrapper = (0,styles_.styled)('div')(({
  theme
}) => ({
  padding: theme.spacing(0, 2),
  height: '100%',
  position: 'absolute',
  pointerEvents: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  color: "#ffffff"
}));
const StyledInputBase = (0,styles_.styled)((InputBase_default()))(({
  theme
}) => ({
  color: 'inherit',
  '& .MuiInputBase-input': {
    color: "#ffffff",
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      width: '12ch',
      '&:focus': {
        width: '20ch'
      }
    }
  }
}));

const DrawerComponent = () => {
  const useStyles = (0,core_.makeStyles)(theme => ({
    drawerContainer: {
      backgroundColor: '#0d0107',
      width: '280px'
    },
    iconButtonContainer: {
      position: 'fixed',
      right: '0',
      color: '#ffffff'
    },
    menuIconToggle: {
      margin: '0 auto',
      fontSize: '6rem',
      width: 'inherit'
    }
  }));
  const {
    0: openDrawer,
    1: setOpenDrawer
  } = (0,external_react_.useState)(false); //Css

  const classes = useStyles();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(core_.Drawer, {
      anchor: "left",
      classes: {
        paper: classes.drawerContainer
      },
      onClose: () => setOpenDrawer(false),
      open: openDrawer,
      onOpen: () => setOpenDrawer(true),
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(core_.List, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(core_.ListItem, {
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: "/Mi-logoWhite.svg",
            alt: "obizatrik",
            width: "220px",
            height: "200px"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(core_.ListItem, {
          style: {
            textAlign: 'center'
          },
          button: true,
          onClick: () => setOpenDrawer(false),
          children: /*#__PURE__*/jsx_runtime_.jsx(core_.ListItemText, {
            style: {
              color: '#ffffff'
            },
            children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: `/`,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                style: {
                  textDecoration: 'none',
                  color: "#ffffff"
                },
                children: "HOME"
              })
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(core_.ListItem, {
          style: {
            textAlign: 'center'
          },
          button: true,
          onClick: () => setOpenDrawer(false),
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(core_.ListItemText, {
            style: {
              color: '#ffffff'
            },
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: `/work`,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                style: {
                  textDecoration: 'none',
                  color: "#ffffff"
                },
                children: "WORK"
              })
            }), " "]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(core_.ListItem, {
          style: {
            textAlign: 'center'
          },
          button: true,
          onClick: () => setOpenDrawer(false),
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(core_.ListItemText, {
            style: {
              textDecoration: 'none',
              color: '#ffffff'
            },
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: `/projects`,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                style: {
                  textDecoration: 'none',
                  color: "#ffffff"
                },
                children: "PROJECTS"
              })
            }), " "]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(core_.ListItem, {
          style: {
            textAlign: 'center'
          },
          button: true,
          onClick: () => setOpenDrawer(false),
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(core_.ListItemText, {
            style: {
              color: '#ffffff'
            },
            children: [" ", /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: `/about`,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                style: {
                  textDecoration: 'none',
                  color: "#ffffff"
                },
                children: "ABOUT"
              })
            })]
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(core_.ListItem, {
          style: {
            textAlign: 'center'
          },
          button: true,
          onClick: () => setOpenDrawer(false),
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(core_.ListItemText, {
            style: {
              color: '#ffffff'
            },
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: `/contacts`,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                style: {
                  textDecoration: 'none',
                  color: "#ffffff"
                },
                children: "CONTACTS"
              })
            }), " "]
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx((Divider_default()), {
        style: {
          width: "230",
          color: '#ffffff'
        },
        variant: "middle"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        style: {
          display: 'flex',
          flexDirection: "column",
          alignItems: 'center '
        },
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(Search, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(SearchIconWrapper, {
            children: /*#__PURE__*/jsx_runtime_.jsx((Search_default()), {})
          }), /*#__PURE__*/jsx_runtime_.jsx(StyledInputBase, {
            placeholder: "Search\u2026",
            inputProps: {
              'aria-label': 'search'
            }
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx(Button/* default */.Z, {
          style: {
            color: '#ffffff',
            fontSize: '16px',
            borderRadius: '5px',
            mt: 5,
            textAlign: "center",
            marginTop: "3vh",
            width: '200px',
            background: "#ff0072",
            '&:hover': {
              background: "rgba(255, 152, 0, 0.75)"
            }
          },
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/contacts",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              style: {
                textDecoration: 'none',
                color: 'white'
              },
              children: "send E-mail"
            })
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          style: {
            marginTop: "3vh"
          },
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(Typography/* default */.Z, {
            style: {
              color: '#ffffff',
              display: 'flex'
            },
            component: "div",
            children: [/*#__PURE__*/jsx_runtime_.jsx((PhoneInTalk_default()), {
              sx: {
                width: "50px",
                marginRight: "1vw"
              }
            }), "+88-01717077230"]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(Typography/* default */.Z, {
            style: {
              color: '#ffffff',
              display: 'flex'
            },
            component: "div",
            children: [/*#__PURE__*/jsx_runtime_.jsx((MailOutline_default()), {
              sx: {
                width: "50px",
                marginRight: "1vw"
              }
            }), "mahmood.islam@gmail.com"]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          style: {
            display: 'flex',
            marginTop: "2vh"
          },
          children: [/*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
            defaulIcon: assets/* linkedInLogo */.Ys,
            onHoverIcon: assets/* linkedInLogoHover */.aj,
            href: "https://www.linkedin.com/in/mahmoodislam/",
            height: "30px",
            width: "30px",
            name: "LinkedIn"
          }), /*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
            defaulIcon: assets/* gmailLogo */.Pv,
            onHoverIcon: assets/* gmailLogoHover */.vR,
            href: "mailto:mahmood.islam@gmail.com",
            height: "30px",
            width: "30px",
            name: "Gmail"
          }), /*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
            defaulIcon: assets/* gitHubLogo */.gA,
            onHoverIcon: assets/* gitHubLogoHover */.X3,
            href: "https://github.com/MahmoodUlislam",
            height: "30px",
            width: "30px",
            name: "GitHub"
          })]
        })]
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(core_.IconButton, {
      className: classes.iconButtonContainer,
      onClick: () => setOpenDrawer(!openDrawer),
      disableRipple: true,
      children: /*#__PURE__*/jsx_runtime_.jsx((icons_Menu_default()), {
        className: classes.menuIconToggle
      })
    })]
  });
};

/* harmony default export */ const utils_DrawerComponent = (DrawerComponent);
;// CONCATENATED MODULE: ./utils/Navbar.jsx























const useStyles = (0,makeStyles/* default */.Z)(theme => ({
  navbar: {
    display: "flex",
    justifyContent: 'flex-start',
    height: "20vh",
    backgroundColor: "#0d0107",
    alignItems: "center"
  },
  appBar: {
    background: "transparent",
    boxShadow: 'none',
    display: "flex",
    alignItems: "center",
    justifyContent: 'center',
    width: '100%',
    position: 'absolute !important'
  }
})); // type MenuBarProps = {
//   activeTab: "Home" | "Work"| "Projects" | "About" | "Contacts" 
// }

function Navbar(props) {
  const {
    0: value,
    1: setValue
  } = (0,external_react_.useState)(0);
  const {
    0: anchorEl,
    1: setAnchorEl
  } = (0,external_react_.useState)(null);
  const classes = useStyles();
  const theme = (0,useTheme/* default */.Z)();
  const isMatch = useMediaQuery_default()(theme.breakpoints.down('sm'));

  const handleClickTab = (e, newValue) => {
    setValue(newValue);
  };

  const handleOpenMenu = e => {
    setAnchorEl(e.currentTarget);
  };

  const handleCloseMenu = () => {
    setAnchorEl(null);
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: classes.navbar,
    children: [isMatch ? /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        style: {
          display: 'flex',
          justifyContent: "center",
          alignItems: 'center'
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx(utils_DrawerComponent, {}), /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
          src: "/Mi-logoWhite.svg",
          alt: "myFace",
          width: "100px",
          height: "82px"
        })]
      })
    }) : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        style: {
          display: 'flex',
          justifyContent: "center",
          alignItems: 'center'
        },
        children: /*#__PURE__*/jsx_runtime_.jsx(AppBar/* default */.Z, {
          className: classes.appBar,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("nav", {
            className: (menubar_module_default()).menuBar,
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: `/`,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                className: (menubar_module_default()).title,
                children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                  src: "/Mi-logoWhite.svg",
                  alt: "myFace",
                  width: "178px",
                  height: "146px"
                }), /*#__PURE__*/jsx_runtime_.jsx("h3", {
                  className: (menubar_module_default()).name,
                  children: "Mahmood ul Islam"
                })]
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: `/`,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: (menubar_module_default()).tab,
                children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
                  style: props.activeTab === "Home" ? {
                    color: "#260316"
                  } : {
                    color: " #ffffff"
                  },
                  children: "Home"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: `/work`,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: (menubar_module_default()).tab,
                children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
                  style: props.activeTab === "Work" ? {
                    color: "#260316"
                  } : {
                    color: "#ffffff"
                  },
                  children: "Work"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: `/projects`,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: (menubar_module_default()).tab,
                children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
                  style: props.activeTab === "Projects" ? {
                    color: "#260316"
                  } : {
                    color: "#ffffff"
                  },
                  children: "Projects"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: `/about`,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: (menubar_module_default()).tab,
                children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
                  style: props.activeTab === "About" ? {
                    color: "#260316"
                  } : {
                    color: "#ffffff"
                  },
                  children: "About"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: `/contacts`,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                className: (menubar_module_default()).tab,
                children: /*#__PURE__*/jsx_runtime_.jsx("h3", {
                  style: props.activeTab === "Contacts" ? {
                    color: "#260316"
                  } : {
                    color: "#ffffff"
                  },
                  children: "Contacts"
                })
              })
            }), /*#__PURE__*/jsx_runtime_.jsx(BackTop/* default */.Z, {})]
          })
        })
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)((Menu_default()), {
      style: {
        marginTop: '5px'
      },
      id: "menu",
      anchorEl: anchorEl,
      open: Boolean(anchorEl),
      onClose: handleCloseMenu,
      children: [/*#__PURE__*/jsx_runtime_.jsx((MenuItem_default()), {
        onClick: handleCloseMenu,
        children: "ABOUT"
      }), /*#__PURE__*/jsx_runtime_.jsx((MenuItem_default()), {
        onClick: handleCloseMenu,
        children: "PROJECTS"
      }), /*#__PURE__*/jsx_runtime_.jsx((MenuItem_default()), {
        onClick: handleCloseMenu,
        children: "EMERGENCY RESPONSE"
      }), /*#__PURE__*/jsx_runtime_.jsx((MenuItem_default()), {
        onClick: handleCloseMenu,
        children: "OUR SUPPORTERS"
      }), /*#__PURE__*/jsx_runtime_.jsx((MenuItem_default()), {
        onClick: handleCloseMenu,
        children: "GALLERY"
      }), /*#__PURE__*/jsx_runtime_.jsx((MenuItem_default()), {
        onClick: handleCloseMenu,
        children: "REPORTS"
      })]
    })]
  });
}

/***/ }),

/***/ 1628:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* binding */ VIcon)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var _icon_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6577);
/* harmony import */ var _icon_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_icon_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_tooltip__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1067);
/* harmony import */ var react_tooltip__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_tooltip__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






function VIcon(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("a", {
    "data-tip": props.tooltipID ? true : false,
    "data-for": props.tooltipID,
    href: props.href,
    target: "_blank",
    className: (_icon_module_scss__WEBPACK_IMPORTED_MODULE_4___default().iconContainer),
    style: {
      height: props.height,
      width: props.width
    },
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      className: (_icon_module_scss__WEBPACK_IMPORTED_MODULE_4___default().iconActive),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__.default, {
        alt: `On hover ${props.name} icon.`,
        src: props.onHoverIcon,
        width: props.width,
        height: props.height
      })
    }), props.tooltipID && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx((react_tooltip__WEBPACK_IMPORTED_MODULE_2___default()), {
      id: props.tooltipID,
      type: "light",
      effect: "solid",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("span", {
        children: props.name
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("div", {
      className: (_icon_module_scss__WEBPACK_IMPORTED_MODULE_4___default().icon),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__.default, {
        alt: `Default ${props.name} icon.`,
        src: props.defaulIcon,
        width: props.width,
        height: props.height
      })
    })]
  });
}

/***/ }),

/***/ 7090:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "cI": () => (/* reexport */ VFooter),
  "Y4": () => (/* reexport */ VMainHeader),
  "sH": () => (/* reexport */ VTimelineGrid),
  "r6": () => (/* reexport */ VToolsTech)
});

// UNUSED EXPORTS: VIcon, VMenuBar, getDate, useTypedText

// EXTERNAL MODULE: ./utils/icon.tsx
var icon = __webpack_require__(1628);
// EXTERNAL MODULE: ./assets/index.ts + 33 modules
var assets = __webpack_require__(5615);
// EXTERNAL MODULE: ./utils/footer.module.scss
var footer_module = __webpack_require__(3657);
var footer_module_default = /*#__PURE__*/__webpack_require__.n(footer_module);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./utils/footer.tsx





function VFooter() {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("footer", {
    className: (footer_module_default()).footer,
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (footer_module_default()).goUpSquare
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("h4", {
      className: (footer_module_default()).copyrights,
      children: ["\xA92021", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Build with ", /*#__PURE__*/jsx_runtime_.jsx("span", {
        children: "Next.js/TypeSript"
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (footer_module_default()).icons,
      children: [/*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
        defaulIcon: assets/* linkedInLogo */.Ys,
        onHoverIcon: assets/* linkedInLogoHover */.aj,
        href: "https://www.linkedin.com/in/mahmoodislam/",
        height: "30px",
        width: "30px",
        name: "LinkedIn"
      }), /*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
        defaulIcon: assets/* gmailLogo */.Pv,
        onHoverIcon: assets/* gmailLogoHover */.vR,
        href: "mailto:mahmood.islam@gmail.com",
        height: "30px",
        width: "30px",
        name: "Gmail"
      }), /*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
        defaulIcon: assets/* gitHubLogo */.gA,
        onHoverIcon: assets/* gitHubLogoHover */.X3,
        href: "https://github.com/MahmoodUlislam",
        height: "30px",
        width: "30px",
        name: "GitHub"
      })]
    })]
  });
}
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./utils/BackTop.jsx
var utils_BackTop = __webpack_require__(4205);
;// CONCATENATED MODULE: ./utils/menubar.tsx






function VMenuBar(props) {
  return /*#__PURE__*/_jsxs("nav", {
    className: styles.menuBar,
    children: [/*#__PURE__*/_jsx(Link, {
      href: `/`,
      children: /*#__PURE__*/_jsxs("a", {
        className: styles.title,
        children: [/*#__PURE__*/_jsx(Image, {
          src: "/Mi-logoWhite.svg",
          alt: "myFace",
          width: "100px",
          height: "100px"
        }), /*#__PURE__*/_jsx("h3", {
          className: styles.name,
          children: "Mahmood ul Islam"
        })]
      })
    }), /*#__PURE__*/_jsx(Link, {
      href: `/`,
      children: /*#__PURE__*/_jsx("a", {
        className: styles.tab,
        children: /*#__PURE__*/_jsx("h3", {
          style: props.activeTab === "Home" ? {
            color: "#260316"
          } : {
            color: " #ffffff"
          },
          children: "Home"
        })
      })
    }), /*#__PURE__*/_jsx(Link, {
      href: `/work`,
      children: /*#__PURE__*/_jsx("a", {
        className: styles.tab,
        children: /*#__PURE__*/_jsx("h3", {
          style: props.activeTab === "Work" ? {
            color: "#260316"
          } : {
            color: "#ffffff"
          },
          children: "Work"
        })
      })
    }), /*#__PURE__*/_jsx(Link, {
      href: `/projects`,
      children: /*#__PURE__*/_jsx("a", {
        className: styles.tab,
        children: /*#__PURE__*/_jsx("h3", {
          style: props.activeTab === "Projects" ? {
            color: "#260316"
          } : {
            color: "#ffffff"
          },
          children: "Projects"
        })
      })
    }), /*#__PURE__*/_jsx(Link, {
      href: `/about`,
      children: /*#__PURE__*/_jsx("a", {
        className: styles.tab,
        children: /*#__PURE__*/_jsx("h3", {
          style: props.activeTab === "About" ? {
            color: "#260316"
          } : {
            color: "#ffffff"
          },
          children: "About"
        })
      })
    }), /*#__PURE__*/_jsx(Link, {
      href: `/contacts`,
      children: /*#__PURE__*/_jsx("a", {
        className: styles.tab,
        children: /*#__PURE__*/_jsx("h3", {
          style: props.activeTab === "Contacts" ? {
            color: "#260316"
          } : {
            color: "#ffffff"
          },
          children: "Contacts"
        })
      })
    }), /*#__PURE__*/_jsx("div", {
      style: {
        display: 'flex',
        position: 'absolute',
        right: '0px',
        bottom: '0px',
        zIndex: 1
      },
      children: /*#__PURE__*/_jsx(BackTop, {})
    })]
  });
}
// EXTERNAL MODULE: ./utils/typingtext.tsx
var typingtext = __webpack_require__(6330);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./utils/home/mainheader.module.scss
var mainheader_module = __webpack_require__(7295);
var mainheader_module_default = /*#__PURE__*/__webpack_require__.n(mainheader_module);
;// CONCATENATED MODULE: ./utils/home/mainheader.tsx





function VMainHeader() {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (mainheader_module_default()).aboutInfo,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("h1", {
      className: (mainheader_module_default()).header,
      children: [(0,typingtext/* useTypedText */.q)("Hello everyone!", 50), /*#__PURE__*/jsx_runtime_.jsx("br", {}), (0,typingtext/* useTypedText */.q)("I'm Mahmood.", 50, 200)]
    }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
      children: (0,typingtext/* useTypedText */.q)("Welcome on my portfolio page! I'm a Software Developer & Designer, currently working as Full-stack Web Developer. Living in Dhaka, Bangladesh.", 30, 350)
    })]
  });
}
// EXTERNAL MODULE: ./utils/home/toolstech.module.scss
var toolstech_module = __webpack_require__(3370);
var toolstech_module_default = /*#__PURE__*/__webpack_require__.n(toolstech_module);
;// CONCATENATED MODULE: ./utils/home/toolstech.tsx






function VToolsTech() {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (toolstech_module_default()).technologiesIcons,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (toolstech_module_default()).technologiesIconsRow,
      children: [/*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
        defaulIcon: assets/* htmlLogo */.ge,
        onHoverIcon: assets/* htmlLogoHover */.Jv,
        height: "76px",
        width: "76px",
        name: "HTML",
        tooltipID: "html-tooltip"
      }), /*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
        defaulIcon: assets/* cssLogo */.QC,
        onHoverIcon: assets/* cssLogoHover */.OA,
        height: "76px",
        width: "76px",
        name: "CSS",
        tooltipID: "css-tooltip"
      }), /*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
        defaulIcon: assets/* jsLogo */.f7,
        onHoverIcon: assets/* jsLogoHover */.po,
        height: "55px",
        width: "55px",
        name: "JavaScript",
        tooltipID: "js-tooltip"
      }), /*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
        defaulIcon: assets/* reactLogo */.rp,
        onHoverIcon: assets/* reactLogoHover */.w0,
        height: "55px",
        width: "55px",
        name: "React",
        tooltipID: "react-tooltip"
      }), /*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
        defaulIcon: assets/* nextLogo */.CJ,
        onHoverIcon: assets/* nextLogoHover */.go,
        height: "100px",
        width: "100px",
        name: "next.js",
        tooltipID: "next.js-tooltip"
      }), /*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
        defaulIcon: assets/* tsLogo */.rq,
        onHoverIcon: assets/* tsLogoHover */.Pz,
        height: "65px",
        width: "65px",
        name: "TypeScript",
        tooltipID: "ts-tooltip"
      }), /*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
        defaulIcon: assets/* sassLogo */.bF,
        onHoverIcon: assets/* sassLogoHover */.bL,
        height: "60px",
        width: "60px",
        name: "Sass",
        tooltipID: "sass-tooltip"
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (toolstech_module_default()).technologiesIconsRow,
      children: [/*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
        defaulIcon: assets/* npmLogo */.Ky,
        onHoverIcon: assets/* npmLogoHover */.Wj,
        height: "65px",
        width: "65px",
        name: "Node Package Manager",
        tooltipID: "npm-tooltip"
      }), /*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
        defaulIcon: assets/* yarnLogo */.os,
        onHoverIcon: assets/* yarnLogoHover */.dP,
        height: "65px",
        width: "65px",
        name: "yarn",
        tooltipID: "yarn-tooltip"
      }), /*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
        defaulIcon: assets/* gitLogo */.Nv,
        onHoverIcon: assets/* gitLogoHover */.lj,
        height: "65px",
        width: "65px",
        name: "Git",
        tooltipID: "git-tooltip"
      }), /*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
        defaulIcon: assets/* jestLogo */.wH,
        onHoverIcon: assets/* jestLogoHover */.AO,
        height: "50px",
        width: "50px",
        name: "Jest",
        tooltipID: "jest-tooltip"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (toolstech_module_default()).technologiesIconsRow,
      children: /*#__PURE__*/jsx_runtime_.jsx(icon/* VIcon */.t, {
        defaulIcon: assets/* vsLogo */.XL,
        onHoverIcon: assets/* vsLogoHover */.wF,
        height: "50px",
        width: "50px",
        name: "Visual Studio Code",
        tooltipID: "vs-tooltip"
      })
    })]
  });
}
;// CONCATENATED MODULE: ./utils/home/index.ts


;// CONCATENATED MODULE: ./utils/date.ts
function getDate() {
  const date = new Date();
  const year = String(date.getFullYear());
  let month = String(date.getMonth() + 1);
  let day = String(date.getDate());
  if (day.length === 1) day = '0' + day;
  if (month.length === 1) month = '0' + month;
  return `${day}.${month}.${year}`;
}
// EXTERNAL MODULE: ./utils/work/timelinegrid.module.scss
var timelinegrid_module = __webpack_require__(4635);
var timelinegrid_module_default = /*#__PURE__*/__webpack_require__.n(timelinegrid_module);
;// CONCATENATED MODULE: ./utils/work/timelinegrid.tsx





function VTimelineGrid() {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: (timelinegrid_module_default()).timelineGrid,
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (timelinegrid_module_default()).timelineGridItemWide,
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        children: "2018"
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (timelinegrid_module_default()).timelinePoint
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (timelinegrid_module_default()).timelineGridItemCard,
      children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
        className: (timelinegrid_module_default()).hoverTip,
        children: "Hover to zoom..."
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (timelinegrid_module_default()).cardContent,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (timelinegrid_module_default()).cardContentHeader,
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (timelinegrid_module_default()).companyLogo,
            children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
              alt: "Quantic Dynamics logo.",
              src: "/Quantic-Dynamics-Logo-Red-4.0-500px.png",
              height: 50,
              width: 150
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (timelinegrid_module_default()).companyInfo,
            children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: (timelinegrid_module_default()).companyTitle,
              children: "Quantic Dynamics ltd."
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: (timelinegrid_module_default()).cardContentDetails,
              children: "Senior web developer "
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: (timelinegrid_module_default()).cardContentDetails,
              children: "(March, 2018 \u2013 Present)"
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          className: (timelinegrid_module_default()).cardContentDescription,
          children: ["Building on my own a responsive web application, which had a catalogue of all company's servers, displayed in the tree structure. Server's data was taken and parsed from XML file to JSON. Anyone logged could browse through lists of servers. Search and sort by name function were applied. App had system of accounts as well. Admins, technical and user ones. Admins could manage accounts by editing them, deleting and authorize (every new user had to be authorized by admin). Admins could also see what user is logged at the moment.", /*#__PURE__*/jsx_runtime_.jsx("br", {}), /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Main responsibilities:", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "- designing both frontend and backend side of the app,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "- creating an asynchronous communication between client and server via ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "REST API"
          }), ",", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "- setting up server with database.", /*#__PURE__*/jsx_runtime_.jsx("br", {}), /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Languages: JavaScript, ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "React.js"
          }), ", ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "Next.js"
          }), ".", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Database: ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "MongoDB"
          }), ",", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "Firebase"
          }), ".", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Styling: ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "Material UI"
          }), ", ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "Ant Design UI"
          }), ", ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "React-boostrap"
          }), ", SASS, boostrap, CSS.", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Version Control System: ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "GitHub."
          }), /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Issue trancing: Trello."]
        })]
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (timelinegrid_module_default()).timelineGridItemAdjoiningCard
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (timelinegrid_module_default()).timelineGridItem
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (timelinegrid_module_default()).timelineGridItem
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (timelinegrid_module_default()).timelineGridItemWide,
      children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
        children: "03.2019 - 03.2020"
      }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
        children: "Working & learning Web Development in Dhaka"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (timelinegrid_module_default()).timelineGridItemAdjoiningCard
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (timelinegrid_module_default()).timelineGridItem
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (timelinegrid_module_default()).timelineGridItem
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (timelinegrid_module_default()).timelineGridItemCard,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (timelinegrid_module_default()).cardContent,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (timelinegrid_module_default()).cardContentHeader,
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (timelinegrid_module_default()).companyLogo,
            children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
              alt: "Crown systems logo",
              src: "/only-sign-logo-[Converted].png",
              height: 30,
              width: 50
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (timelinegrid_module_default()).companyInfo,
            children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: (timelinegrid_module_default()).companyTitle,
              children: "Crown Systems"
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: (timelinegrid_module_default()).cardContentDetails,
              children: "Senior web developer "
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: (timelinegrid_module_default()).cardContentDetails,
              children: "08.2020 - 10.2020"
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          className: (timelinegrid_module_default()).cardContentDescription,
          children: ["Building on my own a responsive web application, which had a catalogue of all company's servers, displayed in the tree structure. Server's data was taken and parsed from XML file to JSON. Anyone logged could browse through lists of servers. Search and sort by name function were applied. App had system of accounts as well. Admins, technical and user ones. Admins could manage accounts by editing them, deleting and authorize (every new user had to be authorized by admin). Admins could also see what user is logged at the moment.", /*#__PURE__*/jsx_runtime_.jsx("br", {}), /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Main responsibilities:", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "- designing both frontend and backend side of the app,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "- creating an asynchronous communication between client and server via ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "REST API"
          }), ",", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "- setting up server with database.", /*#__PURE__*/jsx_runtime_.jsx("br", {}), /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Languages: JavaScript, ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "React.js"
          }), ", ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "Next.js"
          }), ".", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Database: ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "MongoDB"
          }), ",", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "Firebase"
          }), ".", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Styling: ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "Material UI"
          }), ", ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "Ant Design UI"
          }), ", ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "React-boostrap"
          }), ", CSS.", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Version Control System: ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "GitHub."
          }), /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Issue trancing: Trello."]
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (timelinegrid_module_default()).timelineGridItem
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (timelinegrid_module_default()).timelineGridItem
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (timelinegrid_module_default()).timelineGridItemCard,
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (timelinegrid_module_default()).cardContent,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: (timelinegrid_module_default()).cardContentHeader,
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (timelinegrid_module_default()).companyLogo,
            children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
              alt: "Crown systems logo",
              src: "/only-sign-logo-[Converted].png",
              height: 30,
              width: 50
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: (timelinegrid_module_default()).companyInfo,
            children: [/*#__PURE__*/jsx_runtime_.jsx("h1", {
              className: (timelinegrid_module_default()).companyTitle,
              children: "Crown Systems"
            }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
              className: (timelinegrid_module_default()).cardContentDetails,
              children: "Senior web developer"
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("h2", {
              className: (timelinegrid_module_default()).cardContentDetails,
              children: ["10.2020 - ", getDate()]
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
          className: (timelinegrid_module_default()).cardContentDescription,
          children: ["Building from scratch a complete WebRTC Phone web application, based on SIP.js library. Major functionalities:", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "- making new, answering, and holding calls (conferences as well),", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "- contacts list with functionality of adding, deleting, and editing contacts. Search and sort options applied as well,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "- history of calls with summarized data,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "- voicemail and DTMF sending,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "- account and phone input/output audio settings.", /*#__PURE__*/jsx_runtime_.jsx("br", {}), /*#__PURE__*/jsx_runtime_.jsx("br", {}), "My main responsibilities on the front-end side of the project:", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "-working collaboratively in team environment, resolving conflicts,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "-writing a clean and high-quality codebase,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "-refactoring of codebase,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "-writing the documentation,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "-implementation of the functionalities from the documentation, given previously by PM,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "-creating responsive, accessible and efficient web views, based on previously given mockups,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "-reviewing pull requests of my less experienced peers, and helping them with styling/creating components,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "-writing efficient unit tests.", /*#__PURE__*/jsx_runtime_.jsx("br", {}), /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Achievements I am most proud of:", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "-building a 'light' version of main application that could be inserted into an iframe and creating an API via those two elements could communicate,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "-helping my peer with fixing up commit history on main branch in out project, after his mistaken merging,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "-creating documentation with code standards of codebase of our project,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "-implementing CSS modules into our main project, which improved team workflow noticeably,", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "-constructing complete translation system which let the user to change language of application (if not chosen, language was detected automatically).", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Agile management: ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "Scrum, Agile"
          }), ".", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Version control system: ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "Azure DevOps, GitLab"
          }), ".", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Issue tracking tool: ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "Jira, Trelllo"
          }), ".", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Knowledge repository: ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "Confluence"
          }), ".", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Styling: ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "Material UI"
          }), ", ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "Ant Design UI"
          }), ", ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "React-boostrap"
          }), ", SASS, boostrap, CSS.", /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Testing: ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "React Testing Library, JEST"
          }), ", ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "Puppeteer"
          }), /*#__PURE__*/jsx_runtime_.jsx("br", {}), "Communication tool: ", /*#__PURE__*/jsx_runtime_.jsx("b", {
            children: "Microsoft Teams, Google meets,  Zoom"
          }), "."]
        })]
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (timelinegrid_module_default()).timelineGridItemAdjoiningCard
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (timelinegrid_module_default()).timelineGridItem
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: (timelinegrid_module_default()).timelineGridItem
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: (timelinegrid_module_default()).timelineGridItemWide,
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: (timelinegrid_module_default()).timelinePoint
      }), /*#__PURE__*/jsx_runtime_.jsx("h1", {
        children: getDate()
      })]
    })]
  });
}
;// CONCATENATED MODULE: ./utils/work/index.ts

;// CONCATENATED MODULE: ./utils/index.ts








/***/ }),

/***/ 6330:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* binding */ useTypedText)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useTypedText(text, speed, delayTime) {
  const [textState, setTextState] = react__WEBPACK_IMPORTED_MODULE_0___default().useState("");
  const chars = text.split("");
  let interval = speed;
  if (textState.length === 0 && delayTime) interval = speed + delayTime;
  react__WEBPACK_IMPORTED_MODULE_0___default().useEffect(() => {
    const timer = setTimeout(() => {
      setTextState(prevText => {
        if (prevText.length !== chars.length) {
          const newText = prevText.concat(chars[prevText.length]);
          return newText;
        }

        return prevText;
      });
    }, interval);
    return () => clearTimeout(timer);
  });
  return textState;
}

/***/ }),

/***/ 3657:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "footer_footer__xKIqH",
	"goUpSquare": "footer_goUpSquare__2PcKR",
	"copyrights": "footer_copyrights__2-imo",
	"icons": "footer_icons__2Ux__"
};


/***/ }),

/***/ 7295:
/***/ ((module) => {

// Exports
module.exports = {
	"aboutInfo": "mainheader_aboutInfo__1w6u-",
	"header": "mainheader_header__2dw81"
};


/***/ }),

/***/ 3370:
/***/ ((module) => {

// Exports
module.exports = {
	"technologiesIcons": "toolstech_technologiesIcons__3nd1s",
	"technologiesIconsRow": "toolstech_technologiesIconsRow__1qmSM"
};


/***/ }),

/***/ 6577:
/***/ ((module) => {

// Exports
module.exports = {
	"iconContainer": "icon_iconContainer__3jUI4",
	"icon": "icon_icon__17TqY",
	"iconActive": "icon_iconActive__1F462",
	"fadeIn": "icon_fadeIn__epWss"
};


/***/ }),

/***/ 5237:
/***/ ((module) => {

// Exports
module.exports = {
	"menuBar": "menubar_menuBar__2XW6k",
	"title": "menubar_title__3yKQj",
	"name": "menubar_name__3Yewu",
	"tab": "menubar_tab__mHo0l",
	"onHover": "menubar_onHover__OhHJY"
};


/***/ }),

/***/ 4635:
/***/ ((module) => {

// Exports
module.exports = {
	"timelineGrid": "timelinegrid_timelineGrid__FNCNI",
	"timelineGridItem": "timelinegrid_timelineGridItem__3Bq9q",
	"timelineGridItemCard": "timelinegrid_timelineGridItemCard__3jwSb",
	"timelineGridItemAdjoiningCard": "timelinegrid_timelineGridItemAdjoiningCard__3PbMr",
	"timelineGridItemWide": "timelinegrid_timelineGridItemWide__1Lt0J",
	"timelinePoint": "timelinegrid_timelinePoint__19Oc0",
	"hoverTip": "timelinegrid_hoverTip__Eu51E",
	"pulse": "timelinegrid_pulse__1CzPq",
	"cardContent": "timelinegrid_cardContent__3RCRy",
	"cardContentHeader": "timelinegrid_cardContentHeader__1NGK5",
	"companyInfo": "timelinegrid_companyInfo__M7LIf",
	"companyTitle": "timelinegrid_companyTitle__2HJUM",
	"companyLogo": "timelinegrid_companyLogo__35q4j",
	"cardContentDetails": "timelinegrid_cardContentDetails__3Vwrb",
	"cardContentDescription": "timelinegrid_cardContentDescription__2BiKT"
};


/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;