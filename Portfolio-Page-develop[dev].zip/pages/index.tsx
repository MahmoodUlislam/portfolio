import VHome from "./home"

export default function Home() {
  return (
    <VHome/>
  )
}
