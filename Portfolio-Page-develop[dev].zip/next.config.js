module.exports = {
reactStrictMode: true,
env: {
REACT_APP_GOOGLE_MAP_API_KEY:'AIzaSyAgz3Tlv8m9AYdx_or26x_UZmElZK-zOmM',
REACT_APP_RAPID_API_TRAVEL_API_KEY:'',
REACT_APP_RAPID_API_WEATHER_API_KEY:'',
GMAIL_SERVICE:'service_kt1axgb',
EMAIL_TEMPLATE:'template_g9bz5ie',
EMAILJS_USERID:'user_BGpWSgle5uZtYnn9HHBjV'
  },
}
